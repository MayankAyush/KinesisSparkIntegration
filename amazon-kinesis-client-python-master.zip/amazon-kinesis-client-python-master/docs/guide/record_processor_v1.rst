.. _guide_record_processor_v1

Kinesis Client Record Process Version 1
=======================================
The record processor is the central pillar of the Kinesis Client.  This version of the record processor doesn't accept
as much information, and so it's recommended that you don't use this version anymore.

Record Processor API
--------------------

.. autoclass:: amazon_kclpy.kcl.RecordProcessorBase
    :members:


